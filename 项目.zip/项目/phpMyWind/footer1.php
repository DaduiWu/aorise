    <!-- start 底部 -->
   		<div class="footer1">
	        <div class="col-lg-12 col-md-12 col-xs-12">
	        	<div class="s-image">
	            	<img src="images/header-logo.png" alt="" />
	        	</div>
	        </div>
	        <div class="col-lg-12 col-md-12 col-xs-12">
		        <div class="article_a">
		            <p>合作热线：4008745099 18307459777 公司地址：湖南省怀化市鹤城区河西市政协大楼</p> 
		        </div>
		    </div>
		    <div class="col-lg-12 col-md-12 col-xs-12">
		        <div class="article_b">
		            <p>opyright © 2014 - 2017 aorise All Rights Reserved</p>
		        </div>
		    </div>
		    <div class="col-lg-12 col-md-12 col-xs-12">
		        <div class="article_c">
		            <p>本栏目文字内容归aorise.cn所有，任何单位及个人未经许可，不得擅自转摘使用</p>
		        </div>
		    </div>
		    <div class="col-lg-12 col-md-12 col-xs-12">
		        <div class="photo">
		                <img src="images/scanCode.PNG" alt="" />
		        </div>
		    </div>
		    <div class="col-lg-12 col-md-12 col-xs-12">  
		        <div class="article_d"><p>奥昇教育公众号</p>
		        </div> 
			</div>
    </div>
   <!-- end 底部 -->