<?php
require_once(dirname(__FILE__).'/include/config.inc.php');

//初始化参数检测正确性
$cid = empty($cid) ? 2 : intval($cid);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(1,$cid); ?>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<link rel="stylesheet" href="css/about.css"/>
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
</head>
<body>
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->
<!-- banner-->
<div class="subBanner"> <img src="templates/default/images/15.jpg" /> </div>
<!-- /banner-->
<!-- mainbody-->
<div class="header">
	<div class="s-title-a">公司简介</div>
	<div class="s-title-b">您当前所在位置:首页>关于我们>公司简介</div>
</div>

	<div class="about">
		<div class="aorise-title">
				<a href="about.php">关于我们</a>
			</div>
		<div class="aorise-wrap"></div>
		<div class="s-content">
			<div class="container">
				<div class="row">


				<?php
					$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=27  AND orderid ORDER BY orderid asc  LIMIT 0,1");
					while($row = $dosql->GetArray())
					{
						if($row['linkurl'] != '')$gourl = $row['linkurl'];
						else $gourl = 'javascript:;';
				?>



                    <div class="col-lg-4 col-md-4 col-xs-4" >
		                    <img src="images/19.jpg" alt=""	/>
							<p>关于我们/aboutUs</p> 
						<div class="article">
							<img src="images/18.jpg" alt=""	/>	
							<ul>
								<li><a href="about.php">公司简介</a></li>
								<li><a href="aboutUs.php">荣誉资质</a></li>
								<li>企业文化</li>
								<li>董事长致辞</li>
								<li>公司风采</li>
								<li>合作伙伴</li>
								<li>公司地址</li>
							</ul>
						</div>
					</div>

			 <?php
			 }
			 ?>



				



				<?php
					$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=28 AND orderid ORDER BY orderid desc  LIMIT 0,3");
					while($row = $dosql->GetArray())
					{
						if($row['linkurl'] != '')$gourl = $row['linkurl'];
						else $gourl = 'javascript:;';
				?>

		            <div class="col-lg-8 col-md-8 col-xs-8" >
		                    <div class="content-article">
		                    	<?php echo $row['content']; ?>
							</div>
		            </div>

				 <?php
			 }
			 ?>
					
					</div>

		       	</div>
            	</div>
            </div>
        </div>
    </div>






</div>
<!-- /mainbody-->
<!-- footer-->
<?php require_once('footer7.php'); ?>
<!-- /footer-->
</body>
</html>