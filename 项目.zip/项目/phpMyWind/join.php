<?php require_once(dirname(__FILE__).'/include/config.inc.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(1,0,0,'人才招聘'); ?>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<link rel="stylesheet" href="css/join.css"/>
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
</head>
<body>
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->
<!-- banner-->
<div class="subBanner"> <img src="templates/default/images/16.jpg" /> </div>
<!-- /banner-->
<!-- mainbody-->
<div class="header">
	<div class="s-title-a">加入奥昇</div>
	<div class="s-title-b">您当前所在位置:首页>加入奥昇</div>
</div>


	<div class="s-content">
		<div class="container">
			<div class="row">
                <div class="col-lg-12 col-md-12 col-xs-12" >
                    <div class="s-content-join">
						<div class="s-title1">
							<p>前言</p>
						</div>
						<div class="s-title2">
							<p>湖南奥昇对政协工作的领导更加有力，形成了党委重视、政府支持、政协主动、各方配合、社会关注的良好局面。把政协工作纳入党委工作整体布局，党委常委会定期研究政协工作，党政主要领导分工联系政协、参加政协重要会议和活动，政协主席列席党政有关重要会议。</p>
						</div>
						<div class="s-title3">
							请输入职位 <input type="buttom" value="关键字..." />
						</div>
						<div class="s-title4">
							<input type="submit" value="搜索" />
						</div>
						<div class="s-title5">
							<p>软件研发部经理/高级软件工程师</p>
						</div>
						<div class="s-title6">
							<p>职位描述:</p>
						</div>
						<div class="s-title7">
							<p>1、软件的程序设计与代码编写。2、有关技术方案、文档的编写，软件单元的测试。3、根据项目具体要求，承担开发任务，按计划完成任务目标。4、配合系统分析人员完成软件系统以及模块的需求调研、需求分析。5、独立完成软件系统及模块的编码。6、协助测试人员完成软件系统及模块的测试。7、负责编制与项目相关的技术文档。8、根据项目具体要求，承担大型网站设计与开发。9、部分软件功能模块设计和软件界面美化。</p>
						</div>
						<div class="s-title8">
							<p>发布时间 :</p>
							<time datetime="">2015-09-15 有效时间: </time>
						</div>
						<div class="s-title9">
							<p>不限</p>
						</div>
						<div class="s-title10">
							<p>互联网软件开发工程师</p>
						</div>
						<div class="s-title11">
							<p>职位描述:</p>
						</div>
						<div class="s-title12">
							<p>1、软件的程序设计与代码编写。2、有关技术方案、文档的编写，软件单元的测试。</p>
						</div>
						<div class="s-title13">
							<p>发布时间 :</p>
							<time datetime="">2015-09-15 有效时间: </time>
						</div>
						<div class="s-title14">
							<p>不限</p>
						</div>
						<div class="s-title15">
							<p>高级软件工程师(Java)</p>
						</div>
						<div class="s-title16">
							<p>职位描述:</p>
						</div>
						<div class="s-title17">
							<p>1、软件的程序设计与代码编写。2、有关技术方案、文档的编写，软件单元的测试。</p>
						</div>
						<div class="s-title18">
							<p>发布时间 :</p>
							<time datetime="">2012-01-17 有效时间: </time>
						</div>
						<div class="s-title19">
							<p>截至2015-10-1</p>
						</div>
						<div class="s-title20">
							<p>项目经理(数字教育-三通两平台)</p>
						</div>
						<div class="s-title21">
							<p>职位描述:</p>
						</div>
						<div class="s-title22">
							<p>1、计划和规划项目工程。项目管理过程中经济活动要纳入计划管理，规划好项目的实施步骤和预测效果。2、负责整理整个工程项目的财务收支和成本核算，项目中一切发生的经济往来帐项登记入账。3、与材料供应商洽谈好项目过程所需的物料，核算成本，签订物料供需合同，合理使用物料。4、项目工程所需设备与供应商洽谈和合作，有项目经理部按单位工程用料和物资设备部门签订供需包保合同。5、对工程质量、安全、行政管理，测试，等工作的评估，对从决策到实施，从实施到检测过程的检查、考核和严格的管理。6、执行公司规定的其他项目工程事项。项目经理这个岗位肩负的责任比一般岗位肩负的责任比较大，因为这关乎到一个企业对项目的执行能力。除了要有基本的项目执行能力，整个项目的规划和评估工作都要做好。</p>
						</div>
						<div class="s-title23">
							<p>发布时间 :</p>
							<time datetime="">2015-09-15 有效时间: </time>
						</div>
						<div class="s-title24">
							<p>长期</p>
						</div>
						<div class="s-title25">
							<p>项目经理(数字医疗方向)</p>
						</div>
						<div class="s-title26">
							<p>职位描述:</p>
						</div>
						<div class="s-title27">
							<p>1、计划和规划项目工程。项目管理过程中经济活动要纳入计划管理，规划好项目的实施步骤和预测效果。2、负责整理整个工程项目的财务收支和成本核算，项目中一切发生的经济往来帐项登记入账。3、与材料供应商洽谈好项目过程所需的物料，核算成本，签订物料供需合同，合理使用物料。4、项目工程所需设备与供应商洽谈和合作，有项目经理部按单位工程用料和物资设备部门签订供需包保合同。5、对工程质量、安全、行政管理，测试，等工作的评估，对从决策到实施，从实施到检测过程的检查、考核和严格的管理。6、执行公司规定的其他项目工程事项。项目经理这个岗位肩负的责任比一般岗位肩负的责任比较大，因为这关乎到一个企业对项目的执行能力。除了要有基本的项目执行能力，整个项目的规划和评估工作都要做好。</p>
						</div>
						<div class="s-title28">
							<p>发布时间 :</p>
							<time datetime="">2015-09-15 有效时间: </time>
						</div>
						<div class="s-title29">
							<p>不限</p>
						</div>
						<div class="s-title30">
							<p>IOS/Android无线研发工程师</p>
						</div>
						<div class="s-title31">
							<p>职位描述:</p>
						</div>
						<div class="s-title32">
							<p>-负责垂直类目安卓、IOS系统的软件设计,研发 - 快速进行Demo研发 - 依据项目进度与需求,能按时完成所需功能开发</p>
						</div>
						<div class="s-title33">
							<p>发布时间 :</p>
							<time datetime="">2015-01-17 有效时间: </time>
						</div>
						<div class="s-title34">
							<p>3个月</p>
						</div>
						<div class="s-title35">
							<p>销售运营专员</p>
						</div>
						<div class="s-title36">
							<p>职位描述:</p>
						</div>
						<div class="s-title37">
							<p>1、根据部门总体市场策略编制自己分管的市场的销售计划。2、全面掌握本市场的变化和竞争对手情况，了解客源市场布置的流量，注意市场结构的变化。3、对本市场中的客源大户要熟悉他们的基本情况，随时关注其变化并适时做出应对。4、组织本组组员对新市场进行开发。5、管理开发好自己的客户。6、负责组织销售计划的审定及落实，并进行督查。7、掌握每位销售人员每日销售接待活动，并审核销售记录卡。协助部门经理做好本市场客户的建立及升级管理工作，保持客户档案的完整。8、每天早晨组织销售员 9、根据工作需要对小组人员配备提出意见并编制本组培训计划，并督导培训计划的落实。10、每周组织销售员完成部门周例会</p>
						</div>
						<div class="s-title38">
							<p>发布时间 :</p>
							<time datetime="">2015-01-17 有效时间: </time>
						</div>
						<div class="s-title39">
							<p>6个月</p>
						</div>
						<div class="s-title40">
							<p>共1页7条记录</p>
						</div>
					</div>
                </div>
            </div>
        </div>
    </div>


<!-- footer-->
<?php require_once('footer8.php'); ?>
<!-- /footer-->
</body>
</html>