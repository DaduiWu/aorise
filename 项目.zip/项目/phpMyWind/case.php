<?php
require_once(dirname(__FILE__).'/include/config.inc.php');

//初始化参数检测正确性
$cid = empty($cid) ? 8 : intval($cid);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(1,$cid); ?>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<link rel="stylesheet" href="css/case.css"/>
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/loadimage.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
<script type="text/javascript">
$(function(){
    $(".caselist a.img img").LoadImage({width:100,height:80});
});
</script>
</head>
<body>
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->
<!-- banner-->
<div class="subBanner"> <img src="templates/default/images/9.jpg" /> </div>
<!-- /banner-->

<!-- mainbody-->
	<div class="header">
			<div class="s-title-a">案例展示</div>
			<div class="s-title-b">您当前所在位置:首页>案例展示</div>
    </div>

	<div class="case">
		<div class="aorise-title">
			<a href="case.php">案例展示</a>
		</div>
		<div class="s-content">
			<div class="container">
				<div class="row">

				<?php
			$dosql->Execute("SELECT * FROM `#@__infoimg` WHERE classid=8  AND delstate='' AND checkinfo=true ORDER BY orderid asc   LIMIT 0,3");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>

                    <div class="col-lg-4 col-md-4 col-xs-4" >

                        <div class="s-content-case">
							<div class="s-image">
								<img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>">
							</div>
							<div class="s-content1">
								<div class="s-image-title"><?php echo $row['title']; ?></div>
							</div>
							
						</div>
                    </div>
                    <?php
			         }
			         ?>
				</div>

				<div class="row">

				<?php
			$dosql->Execute("SELECT * FROM `#@__infoimg` WHERE classid=22  AND delstate='' AND checkinfo=true ORDER BY orderid asc   LIMIT 0,3");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>

                    <div class="col-lg-4 col-md-4 col-xs-4" >

                        <div class="s-content-case">
							<div class="s-image">
								<img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>">
							</div>
							<div class="s-content3">
								<div class="s-image-title"><?php echo $row['title']; ?></div>
							</div>
						</div>
                    </div>
                    <?php
			         }
			         ?>
				</div>
			</div>		
		</div>
	</div>

</div>
<!-- /mainbody-->
<!-- footer-->
	    <?php require_once('footer4.php'); ?>
<!-- /footer-->
</body>
</html>